import requests


def script():



    # start : 1467623525.76
    headers = {"Host": "nsclick.baidu.com", "Proxy-Connection": "keep-alive",
               "User-Agent": "Mozilla/5.0 (Linux; Android 5.1; m2 note Build/LMY47D) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.81 Mobile Safari/537.36",
               "Accept": "image/webp,image/*,*/*;q=0.8",
               "Referer": "http://wapbaike.baidu.com/subview/7410/5040563.htm?fr=aladdin&ref=wise&ssid=0&from=844b&uid=0&pu=usm@2,sz@1320_1001,ta@iphone_2_5.1_3_537&bd_page_type=1&baiduid=D1D8246AC804B5D314977701F7E75E7D&tj=Xv_2_0_10_title",
               "Accept-Encoding": "gzip, deflate, sdch", "Accept-Language": "zh-CN,zh;q=0.8,en;q=0.6",
               "Cookie": "plus_cv=0::m:1-nav:250e8bac-hotword:a6eb63c2; plus_lsv=4388bdbef257d8ef; BAIDULOC=12960396.239553755_4834358.330481074_35_131_1467606415694; H5LOC=1; BAIDUID=D1D8246AC804B5D314977701F7E75E7D:FG=1"}
    r = requests.get(
        "http://nsclick.baidu.com/v.gif?pid=103&url=http%3A%2F%2Fwapbaike.baidu.com%2Fsubview%2F7410%2F5040563.htm%3Ffr%3Daladdin%26ref%3Dwise%26ssid%3D0%26from%3D844b%26uid%3D0%26pu%3Dusm%402%2Csz%401320_1001%2Cta%40iphone_2_5.1_3_537%26bd_page_type%3D1%26baiduid%3DD1D8246AC804B5D314977701F7E75E7D%26tj%3DXv_2_0_10_title&type=20001507&t=1467623524806",
        headers=headers)
    # end : 1467623525.8

    # insert the assert or other check point

    # start : 1467623525.76
    headers = {"Host": "nsclick.baidu.com", "Proxy-Connection": "keep-alive",
               "User-Agent": "Mozilla/5.0 (Linux; Android 5.1; m2 note Build/LMY47D) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.81 Mobile Safari/537.36",
               "Accept": "image/webp,image/*,*/*;q=0.8",
               "Referer": "http://wapbaike.baidu.com/subview/7410/5040563.htm?fr=aladdin&ref=wise&ssid=0&from=844b&uid=0&pu=usm@2,sz@1320_1001,ta@iphone_2_5.1_3_537&bd_page_type=1&baiduid=D1D8246AC804B5D314977701F7E75E7D&tj=Xv_2_0_10_title",
               "Accept-Encoding": "gzip, deflate, sdch", "Accept-Language": "zh-CN,zh;q=0.8,en;q=0.6",
               "Cookie": "plus_cv=0::m:1-nav:250e8bac-hotword:a6eb63c2; plus_lsv=4388bdbef257d8ef; BAIDULOC=12960396.239553755_4834358.330481074_35_131_1467606415694; H5LOC=1; BAIDUID=D1D8246AC804B5D314977701F7E75E7D:FG=1"}
    r = requests.get(
        "http://nsclick.baidu.com/v.gif?pid=103&url=http%3A%2F%2Fwapbaike.baidu.com%2Fsubview%2F7410%2F5040563.htm%3Ffr%3Daladdin%26ref%3Dwise%26ssid%3D0%26from%3D844b%26uid%3D0%26pu%3Dusm%402%2Csz%401320_1001%2Cta%40iphone_2_5.1_3_537%26bd_page_type%3D1%26baiduid%3DD1D8246AC804B5D314977701F7E75E7D%26tj%3DXv_2_0_10_title&type=20001501&t=1467623524815",
        headers=headers)
    # end : 1467623525.8

    # insert the assert or other check point

    # start : 1467623525.76
    headers = {"Host": "nsclick.baidu.com", "Proxy-Connection": "keep-alive",
               "User-Agent": "Mozilla/5.0 (Linux; Android 5.1; m2 note Build/LMY47D) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.81 Mobile Safari/537.36",
               "Accept": "image/webp,image/*,*/*;q=0.8",
               "Referer": "http://wapbaike.baidu.com/subview/7410/5040563.htm?fr=aladdin&ref=wise&ssid=0&from=844b&uid=0&pu=usm@2,sz@1320_1001,ta@iphone_2_5.1_3_537&bd_page_type=1&baiduid=D1D8246AC804B5D314977701F7E75E7D&tj=Xv_2_0_10_title",
               "Accept-Encoding": "gzip, deflate, sdch", "Accept-Language": "zh-CN,zh;q=0.8,en;q=0.6",
               "Cookie": "plus_cv=0::m:1-nav:250e8bac-hotword:a6eb63c2; plus_lsv=4388bdbef257d8ef; BAIDULOC=12960396.239553755_4834358.330481074_35_131_1467606415694; H5LOC=1; BAIDUID=D1D8246AC804B5D314977701F7E75E7D:FG=1"}
    r = requests.get(
        "http://nsclick.baidu.com/v.gif?pid=103&url=http%3A%2F%2Fwapbaike.baidu.com%2Fsubview%2F7410%2F5040563.htm%3Ffr%3Daladdin%26ref%3Dwise%26ssid%3D0%26from%3D844b%26uid%3D0%26pu%3Dusm%402%2Csz%401320_1001%2Cta%40iphone_2_5.1_3_537%26bd_page_type%3D1%26baiduid%3DD1D8246AC804B5D314977701F7E75E7D%26tj%3DXv_2_0_10_title&type=20001508&t=1467623524814&time=1467606424",
        headers=headers)
    # end : 1467623525.8

    # insert the assert or other check point

    # start : 1467623526.2
    headers = {"Host": "nsclick.baidu.com", "Proxy-Connection": "keep-alive",
               "User-Agent": "Mozilla/5.0 (Linux; Android 5.1; m2 note Build/LMY47D) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.81 Mobile Safari/537.36",
               "Accept": "image/webp,image/*,*/*;q=0.8",
               "Referer": "http://wapbaike.baidu.com/subview/7410/5040563.htm?fr=aladdin&ref=wise&ssid=0&from=844b&uid=0&pu=usm@2,sz@1320_1001,ta@iphone_2_5.1_3_537&bd_page_type=1&baiduid=D1D8246AC804B5D314977701F7E75E7D&tj=Xv_2_0_10_title",
               "Accept-Encoding": "gzip, deflate, sdch", "Accept-Language": "zh-CN,zh;q=0.8,en;q=0.6",
               "Cookie": "plus_cv=0::m:1-nav:250e8bac-hotword:a6eb63c2; plus_lsv=4388bdbef257d8ef; BAIDULOC=12960396.239553755_4834358.330481074_35_131_1467606415694; H5LOC=1; BAIDUID=D1D8246AC804B5D314977701F7E75E7D:FG=1"}
    r = requests.get(
        "http://nsclick.baidu.com/v.gif?pid=103&url=http%3A%2F%2Fwapbaike.baidu.com%2Fsubview%2F7410%2F5040563.htm%3Ffr%3Daladdin%26ref%3Dwise%26ssid%3D0%26from%3D844b%26uid%3D0%26pu%3Dusm%402%2Csz%401320_1001%2Cta%40iphone_2_5.1_3_537%26bd_page_type%3D1%26baiduid%3DD1D8246AC804B5D314977701F7E75E7D%26tj%3DXv_2_0_10_title&type=20004406&t=1467623525126",
        headers=headers)
    # end : 1467623526.22

    # insert the assert or other check point

    # start : 1467623526.2
    headers = {"Host": "nsclick.baidu.com", "Proxy-Connection": "keep-alive",
               "User-Agent": "Mozilla/5.0 (Linux; Android 5.1; m2 note Build/LMY47D) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.81 Mobile Safari/537.36",
               "Accept": "image/webp,image/*,*/*;q=0.8",
               "Referer": "http://wapbaike.baidu.com/subview/7410/5040563.htm?fr=aladdin&ref=wise&ssid=0&from=844b&uid=0&pu=usm@2,sz@1320_1001,ta@iphone_2_5.1_3_537&bd_page_type=1&baiduid=D1D8246AC804B5D314977701F7E75E7D&tj=Xv_2_0_10_title",
               "Accept-Encoding": "gzip, deflate, sdch", "Accept-Language": "zh-CN,zh;q=0.8,en;q=0.6",
               "Cookie": "plus_cv=0::m:1-nav:250e8bac-hotword:a6eb63c2; plus_lsv=4388bdbef257d8ef; BAIDULOC=12960396.239553755_4834358.330481074_35_131_1467606415694; H5LOC=1; BAIDUID=D1D8246AC804B5D314977701F7E75E7D:FG=1"}
    r = requests.get(
        "http://nsclick.baidu.com/v.gif?pid=103&url=http%3A%2F%2Fwapbaike.baidu.com%2Fsubview%2F7410%2F5040563.htm%3Ffr%3Daladdin%26ref%3Dwise%26ssid%3D0%26from%3D844b%26uid%3D0%26pu%3Dusm%402%2Csz%401320_1001%2Cta%40iphone_2_5.1_3_537%26bd_page_type%3D1%26baiduid%3DD1D8246AC804B5D314977701F7E75E7D%26tj%3DXv_2_0_10_title&type=20001201&t=1467623525130",
        headers=headers)
    # end : 1467623526.22

    # insert the assert or other check point

    # start : 1467623526.37
    headers = {"Host": "nsclick.baidu.com", "Proxy-Connection": "keep-alive",
               "User-Agent": "Mozilla/5.0 (Linux; Android 5.1; m2 note Build/LMY47D) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.81 Mobile Safari/537.36",
               "Accept": "image/webp,image/*,*/*;q=0.8",
               "Referer": "http://wapbaike.baidu.com/subview/7410/5040563.htm?fr=aladdin&ref=wise&ssid=0&from=844b&uid=0&pu=usm@2,sz@1320_1001,ta@iphone_2_5.1_3_537&bd_page_type=1&baiduid=D1D8246AC804B5D314977701F7E75E7D&tj=Xv_2_0_10_title",
               "Accept-Encoding": "gzip, deflate, sdch", "Accept-Language": "zh-CN,zh;q=0.8,en;q=0.6",
               "Cookie": "plus_cv=0::m:1-nav:250e8bac-hotword:a6eb63c2; plus_lsv=4388bdbef257d8ef; BAIDULOC=12960396.239553755_4834358.330481074_35_131_1467606415694; H5LOC=1; BAIDUID=D1D8246AC804B5D314977701F7E75E7D:FG=1"}
    r = requests.get(
        "http://nsclick.baidu.com/v.gif?pid=103&url=http%3A%2F%2Fwapbaike.baidu.com%2Fsubview%2F7410%2F5040563.htm%3Ffr%3Daladdin%26ref%3Dwise%26ssid%3D0%26from%3D844b%26uid%3D0%26pu%3Dusm%402%2Csz%401320_1001%2Cta%40iphone_2_5.1_3_537%26bd_page_type%3D1%26baiduid%3DD1D8246AC804B5D314977701F7E75E7D%26tj%3DXv_2_0_10_title&type=30000406&t=1467623525455",
        headers=headers)
    # end : 1467623526.41

    # insert the assert or other check point

    # start : 1467623526.37
    headers = {"Host": "nsclick.baidu.com", "Proxy-Connection": "keep-alive",
               "User-Agent": "Mozilla/5.0 (Linux; Android 5.1; m2 note Build/LMY47D) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.81 Mobile Safari/537.36",
               "Accept": "image/webp,image/*,*/*;q=0.8",
               "Referer": "http://wapbaike.baidu.com/subview/7410/5040563.htm?fr=aladdin&ref=wise&ssid=0&from=844b&uid=0&pu=usm@2,sz@1320_1001,ta@iphone_2_5.1_3_537&bd_page_type=1&baiduid=D1D8246AC804B5D314977701F7E75E7D&tj=Xv_2_0_10_title",
               "Accept-Encoding": "gzip, deflate, sdch", "Accept-Language": "zh-CN,zh;q=0.8,en;q=0.6",
               "Cookie": "plus_cv=0::m:1-nav:250e8bac-hotword:a6eb63c2; plus_lsv=4388bdbef257d8ef; BAIDULOC=12960396.239553755_4834358.330481074_35_131_1467606415694; H5LOC=1; BAIDUID=D1D8246AC804B5D314977701F7E75E7D:FG=1"}
    r = requests.get(
        "http://nsclick.baidu.com/v.gif?pid=103&url=http%3A%2F%2Fwapbaike.baidu.com%2Fsubview%2F7410%2F5040563.htm%3Ffr%3Daladdin%26ref%3Dwise%26ssid%3D0%26from%3D844b%26uid%3D0%26pu%3Dusm%402%2Csz%401320_1001%2Cta%40iphone_2_5.1_3_537%26bd_page_type%3D1%26baiduid%3DD1D8246AC804B5D314977701F7E75E7D%26tj%3DXv_2_0_10_title&type=30000403&t=1467623525447",
        headers=headers)
    # end : 1467623526.41

    # insert the assert or other check point

    # start : 1467623526.37
    headers = {"Host": "nsclick.baidu.com", "Proxy-Connection": "keep-alive",
               "User-Agent": "Mozilla/5.0 (Linux; Android 5.1; m2 note Build/LMY47D) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.81 Mobile Safari/537.36",
               "Accept": "image/webp,image/*,*/*;q=0.8",
               "Referer": "http://wapbaike.baidu.com/subview/7410/5040563.htm?fr=aladdin&ref=wise&ssid=0&from=844b&uid=0&pu=usm@2,sz@1320_1001,ta@iphone_2_5.1_3_537&bd_page_type=1&baiduid=D1D8246AC804B5D314977701F7E75E7D&tj=Xv_2_0_10_title",
               "Accept-Encoding": "gzip, deflate, sdch", "Accept-Language": "zh-CN,zh;q=0.8,en;q=0.6",
               "Cookie": "plus_cv=0::m:1-nav:250e8bac-hotword:a6eb63c2; plus_lsv=4388bdbef257d8ef; BAIDULOC=12960396.239553755_4834358.330481074_35_131_1467606415694; H5LOC=1; BAIDUID=D1D8246AC804B5D314977701F7E75E7D:FG=1"}
    r = requests.get(
        "http://nsclick.baidu.com/v.gif?pid=103&url=http%3A%2F%2Fwapbaike.baidu.com%2Fsubview%2F7410%2F5040563.htm%3Ffr%3Daladdin%26ref%3Dwise%26ssid%3D0%26from%3D844b%26uid%3D0%26pu%3Dusm%402%2Csz%401320_1001%2Cta%40iphone_2_5.1_3_537%26bd_page_type%3D1%26baiduid%3DD1D8246AC804B5D314977701F7E75E7D%26tj%3DXv_2_0_10_title&type=20001513&t=1467623525460",
        headers=headers)
    # end : 1467623526.41

    # insert the assert or other check point

    # start : 1467623526.49
    headers = {"Host": "nsclick.baidu.com", "Proxy-Connection": "keep-alive",
               "User-Agent": "Mozilla/5.0 (Linux; Android 5.1; m2 note Build/LMY47D) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.81 Mobile Safari/537.36",
               "Accept": "image/webp,image/*,*/*;q=0.8",
               "Referer": "http://wapbaike.baidu.com/subview/7410/5040563.htm?fr=aladdin&ref=wise&ssid=0&from=844b&uid=0&pu=usm@2,sz@1320_1001,ta@iphone_2_5.1_3_537&bd_page_type=1&baiduid=D1D8246AC804B5D314977701F7E75E7D&tj=Xv_2_0_10_title",
               "Accept-Encoding": "gzip, deflate, sdch", "Accept-Language": "zh-CN,zh;q=0.8,en;q=0.6",
               "Cookie": "plus_cv=0::m:1-nav:250e8bac-hotword:a6eb63c2; plus_lsv=4388bdbef257d8ef; BAIDULOC=12960396.239553755_4834358.330481074_35_131_1467606415694; H5LOC=1; BAIDUID=D1D8246AC804B5D314977701F7E75E7D:FG=1"}
    r = requests.get(
        "http://nsclick.baidu.com/v.gif?pid=103&url=http%3A%2F%2Fwapbaike.baidu.com%2Fsubview%2F7410%2F5040563.htm%3Ffr%3Daladdin%26ref%3Dwise%26ssid%3D0%26from%3D844b%26uid%3D0%26pu%3Dusm%402%2Csz%401320_1001%2Cta%40iphone_2_5.1_3_537%26bd_page_type%3D1%26baiduid%3DD1D8246AC804B5D314977701F7E75E7D%26tj%3DXv_2_0_10_title&type=30000404&t=1467623525570",
        headers=headers)
    # end : 1467623526.51

    # insert the assert or other check point

    # start : 1467623526.5
    headers = {"Host": "nsclick.baidu.com", "Proxy-Connection": "keep-alive",
               "User-Agent": "Mozilla/5.0 (Linux; Android 5.1; m2 note Build/LMY47D) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.81 Mobile Safari/537.36",
               "Accept": "image/webp,image/*,*/*;q=0.8",
               "Referer": "http://wapbaike.baidu.com/subview/7410/5040563.htm?fr=aladdin&ref=wise&ssid=0&from=844b&uid=0&pu=usm@2,sz@1320_1001,ta@iphone_2_5.1_3_537&bd_page_type=1&baiduid=D1D8246AC804B5D314977701F7E75E7D&tj=Xv_2_0_10_title",
               "Accept-Encoding": "gzip, deflate, sdch", "Accept-Language": "zh-CN,zh;q=0.8,en;q=0.6",
               "Cookie": "plus_cv=0::m:1-nav:250e8bac-hotword:a6eb63c2; plus_lsv=4388bdbef257d8ef; BAIDULOC=12960396.239553755_4834358.330481074_35_131_1467606415694; H5LOC=1; BAIDUID=D1D8246AC804B5D314977701F7E75E7D:FG=1"}
    r = requests.get(
        "http://nsclick.baidu.com/v.gif?pid=103&url=http%3A%2F%2Fwapbaike.baidu.com%2Fsubview%2F7410%2F5040563.htm%3Ffr%3Daladdin%26ref%3Dwise%26ssid%3D0%26from%3D844b%26uid%3D0%26pu%3Dusm%402%2Csz%401320_1001%2Cta%40iphone_2_5.1_3_537%26bd_page_type%3D1%26baiduid%3DD1D8246AC804B5D314977701F7E75E7D%26tj%3DXv_2_0_10_title&type=30000407&t=1467623525580",
        headers=headers)
    # end : 1467623526.52

    # insert the assert or other check point

    # start : 1467623526.5
    headers = {"Host": "nsclick.baidu.com", "Proxy-Connection": "keep-alive",
               "User-Agent": "Mozilla/5.0 (Linux; Android 5.1; m2 note Build/LMY47D) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.81 Mobile Safari/537.36",
               "Accept": "image/webp,image/*,*/*;q=0.8",
               "Referer": "http://wapbaike.baidu.com/subview/7410/5040563.htm?fr=aladdin&ref=wise&ssid=0&from=844b&uid=0&pu=usm@2,sz@1320_1001,ta@iphone_2_5.1_3_537&bd_page_type=1&baiduid=D1D8246AC804B5D314977701F7E75E7D&tj=Xv_2_0_10_title",
               "Accept-Encoding": "gzip, deflate, sdch", "Accept-Language": "zh-CN,zh;q=0.8,en;q=0.6",
               "Cookie": "plus_cv=0::m:1-nav:250e8bac-hotword:a6eb63c2; plus_lsv=4388bdbef257d8ef; BAIDULOC=12960396.239553755_4834358.330481074_35_131_1467606415694; H5LOC=1; BAIDUID=D1D8246AC804B5D314977701F7E75E7D:FG=1"}
    r = requests.get(
        "http://nsclick.baidu.com/v.gif?pid=103&url=http%3A%2F%2Fwapbaike.baidu.com%2Fsubview%2F7410%2F5040563.htm%3Ffr%3Daladdin%26ref%3Dwise%26ssid%3D0%26from%3D844b%26uid%3D0%26pu%3Dusm%402%2Csz%401320_1001%2Cta%40iphone_2_5.1_3_537%26bd_page_type%3D1%26baiduid%3DD1D8246AC804B5D314977701F7E75E7D%26tj%3DXv_2_0_10_title&type=20001516&t=1467623525604",
        headers=headers)
    # end : 1467623526.52

    # insert the assert or other check point

    # start : 1467623526.62
    headers = {"Host": "nsclick.baidu.com", "Proxy-Connection": "keep-alive",
               "User-Agent": "Mozilla/5.0 (Linux; Android 5.1; m2 note Build/LMY47D) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.81 Mobile Safari/537.36",
               "Accept": "image/webp,image/*,*/*;q=0.8",
               "Referer": "http://wapbaike.baidu.com/subview/7410/5040563.htm?fr=aladdin&ref=wise&ssid=0&from=844b&uid=0&pu=usm@2,sz@1320_1001,ta@iphone_2_5.1_3_537&bd_page_type=1&baiduid=D1D8246AC804B5D314977701F7E75E7D&tj=Xv_2_0_10_title",
               "Accept-Encoding": "gzip, deflate, sdch", "Accept-Language": "zh-CN,zh;q=0.8,en;q=0.6",
               "Cookie": "plus_cv=0::m:1-nav:250e8bac-hotword:a6eb63c2; plus_lsv=4388bdbef257d8ef; BAIDULOC=12960396.239553755_4834358.330481074_35_131_1467606415694; H5LOC=1; BAIDUID=D1D8246AC804B5D314977701F7E75E7D:FG=1"}
    r = requests.get(
        "http://nsclick.baidu.com/v.gif?pid=103&url=http%3A%2F%2Fwapbaike.baidu.com%2Fsubview%2F7410%2F5040563.htm%3Ffr%3Daladdin%26ref%3Dwise%26ssid%3D0%26from%3D844b%26uid%3D0%26pu%3Dusm%402%2Csz%401320_1001%2Cta%40iphone_2_5.1_3_537%26bd_page_type%3D1%26baiduid%3DD1D8246AC804B5D314977701F7E75E7D%26tj%3DXv_2_0_10_title&type=300001175101&t=1467623525721",
        headers=headers)
    # end : 1467623526.64

    # insert the assert or other check point

    # start : 1467623526.62
    headers = {"Host": "nsclick.baidu.com", "Proxy-Connection": "keep-alive",
               "User-Agent": "Mozilla/5.0 (Linux; Android 5.1; m2 note Build/LMY47D) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.81 Mobile Safari/537.36",
               "Accept": "image/webp,image/*,*/*;q=0.8",
               "Referer": "http://wapbaike.baidu.com/subview/7410/5040563.htm?fr=aladdin&ref=wise&ssid=0&from=844b&uid=0&pu=usm@2,sz@1320_1001,ta@iphone_2_5.1_3_537&bd_page_type=1&baiduid=D1D8246AC804B5D314977701F7E75E7D&tj=Xv_2_0_10_title",
               "Accept-Encoding": "gzip, deflate, sdch", "Accept-Language": "zh-CN,zh;q=0.8,en;q=0.6",
               "Cookie": "plus_cv=0::m:1-nav:250e8bac-hotword:a6eb63c2; plus_lsv=4388bdbef257d8ef; BAIDULOC=12960396.239553755_4834358.330481074_35_131_1467606415694; H5LOC=1; BAIDUID=D1D8246AC804B5D314977701F7E75E7D:FG=1"}
    r = requests.get(
        "http://nsclick.baidu.com/v.gif?pid=103&url=http%3A%2F%2Fwapbaike.baidu.com%2Fsubview%2F7410%2F5040563.htm%3Ffr%3Daladdin%26ref%3Dwise%26ssid%3D0%26from%3D844b%26uid%3D0%26pu%3Dusm%402%2Csz%401320_1001%2Cta%40iphone_2_5.1_3_537%26bd_page_type%3D1%26baiduid%3DD1D8246AC804B5D314977701F7E75E7D%26tj%3DXv_2_0_10_title&type=3000037201&t=1467623525729",
        headers=headers)
    # end : 1467623526.64

    # insert the assert or other check point

    # start : 1467623527.69
    headers = {"Host": "nsclick.baidu.com", "Proxy-Connection": "keep-alive",
               "User-Agent": "Mozilla/5.0 (Linux; Android 5.1; m2 note Build/LMY47D) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.81 Mobile Safari/537.36",
               "Accept": "image/webp,image/*,*/*;q=0.8",
               "Referer": "http://wapbaike.baidu.com/subview/7410/5040563.htm?fr=aladdin&ref=wise&ssid=0&from=844b&uid=0&pu=usm@2,sz@1320_1001,ta@iphone_2_5.1_3_537&bd_page_type=1&baiduid=D1D8246AC804B5D314977701F7E75E7D&tj=Xv_2_0_10_title",
               "Accept-Encoding": "gzip, deflate, sdch", "Accept-Language": "zh-CN,zh;q=0.8,en;q=0.6",
               "Cookie": "plus_cv=0::m:1-nav:250e8bac-hotword:a6eb63c2; plus_lsv=4388bdbef257d8ef; BAIDULOC=12960396.239553755_4834358.330481074_35_131_1467606415694; H5LOC=1; BAIDUID=D1D8246AC804B5D314977701F7E75E7D:FG=1"}
    r = requests.get(
        "http://nsclick.baidu.com/v.gif?pid=103&url=http%3A%2F%2Fwapbaike.baidu.com%2Fsubview%2F7410%2F5040563.htm%3Ffr%3Daladdin%26ref%3Dwise%26ssid%3D0%26from%3D844b%26uid%3D0%26pu%3Dusm%402%2Csz%401320_1001%2Cta%40iphone_2_5.1_3_537%26bd_page_type%3D1%26baiduid%3DD1D8246AC804B5D314977701F7E75E7D%26tj%3DXv_2_0_10_title&type=30000401&t=1467623526751&blockInfo={%22mobile-lemma-top-ad%22:{%22isValid%22:true},%22mobile-lemma-float-ad%22:{%22isValid%22:true}}&page=mobile-lemma",
        headers=headers)
    # end : 1467623527.7

    # insert the assert or other check point



    # start : 1467623531.78
